document.getElementById("demo").innerHTML = "Hello JavaScript";

document.getElementById("demo").style.fontSize = "70px";
document.getElementById("demo").style.display = "block";
document.getElementById("demo").style.display = "none";


document.getElementById("mano").style.fontSize = "70px";
document.getElementById("mano").style.display = "block";
document.getElementById("mano").style.display = "none";